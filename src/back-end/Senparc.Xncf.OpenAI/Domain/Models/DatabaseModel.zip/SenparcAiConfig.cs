﻿using Senparc.Ncf.Core.Models;
using System;
using System.ComponentModel.DataAnnotations;

namespace Senparc.Xncf.OpenAI.Domain.Models.DatabaseModel
{
    /// <summary>
    /// OpenAiConfig 实体类
    /// </summary>
    [System.ComponentModel.DataAnnotations.Schema.TableAttribute(Register.DATABASE_PREFIX + nameof(SenparcAiConfig))]//必须添加前缀，防止全系统中发生冲突
    [Serializable]
    public class SenparcAiConfig : EntityBase<int>
    {
        public bool IsDebug { get; set; }

        [MaxLength(50)]
        public string AiPlatform { get; set; }

        public NeuCharOpenAiConfig NeuCharOpenAi { get; set; } = new NeuCharOpenAiConfig();

        public AzureOpenAiConfig AzureOpenAi { get; set; } = new AzureOpenAiConfig();

        public OpenAiConfig OpenAi { get; set; } = new OpenAiConfig();
    }
}
