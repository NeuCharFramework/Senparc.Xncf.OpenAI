﻿using Senparc.Ncf.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Senparc.Xncf.OpenAI.Domain.Models.DatabaseModel.Dto
{
    public class SenparcAiSettingDto : DtoBase
    {
        public string AiPlatform { get; set; }
        public OpenAiConfigDto OpenAiConfig{ get; set; } = new OpenAiConfigDto();
        public AzureOpenAiConfigDto AzureOpenAiConfig { get; set; } = new AzureOpenAiConfigDto();
        public NeuCharOpenAiConfigDto NeuCharOpenAiConfig { get; set; } = new NeuCharOpenAiConfigDto();
    }
}
