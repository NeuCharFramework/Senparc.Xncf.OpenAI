﻿using Senparc.CO2NET.Extensions;
using Senparc.Ncf.Core.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Senparc.Xncf.OpenAI.Domain.Models.DatabaseModel
{
    public class OpenAiConfig : EntityBase<int>
    {
        [MaxLength(100)]
        public string ApiKey { get; set; }

        [MaxLength(100)]
        public string OrganizationId { get; set; }
        public void Update(string apiKey, string organizationID)
        {
            if (!apiKey.IsNullOrEmpty())
            {
                ApiKey = Convert.ToBase64String(Encoding.UTF8.GetBytes(apiKey));
            }
            OrganizationId = organizationID;
        }

        public string GetOriginalAppKey()
        {
            return Encoding.Default.GetString(Convert.FromBase64String(ApiKey));
        }
    }
}
